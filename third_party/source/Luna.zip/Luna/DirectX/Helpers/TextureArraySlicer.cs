using FFXIVClientStructs.FFXIV.Client.Graphics.Kernel;
using TerraFX.Interop.DirectX;
using TerraFX.Interop.Windows;

namespace Luna.DirectX;

/// <summary> Creates ImGui texture handles over slices of array textures, and manages their lifetime. </summary>
public sealed unsafe class TextureArraySlicer : IUiService, IDisposable
{
    private const uint InitialTimeToLive = 2;

    private readonly Dictionary<(nint XivTexture, byte SliceIndex), SliceState> _activeSlices = [];
    private readonly HashSet<(nint XivTexture, byte SliceIndex)>                _expiredKeys  = [];

    /// <summary> Create a texture array slicer. </summary>
    public TextureArraySlicer()
        => ImSharpPerFrame.Update += Tick;

    /// <summary> Gets an ImGui texture handle over a slice of the given array texture. </summary>
    /// <param name="texture"> The texture of which to get a slice. </param>
    /// <param name="sliceIndex"> The index of the slice to get. Must be less than <see cref="Texture.ArraySize"/>. </param>
    /// <returns> An ImGui texture handle, to use with all ImGui image functions. </returns>
    /// <remarks> Caching this across frames will cause a crash to desktop. </remarks>
    public ImTextureId GetImGuiHandle(Texture* texture, byte sliceIndex)
    {
        if (texture is null)
            throw new ArgumentNullException(nameof(texture));
        if (sliceIndex >= texture->ArraySize)
            throw new ArgumentOutOfRangeException(nameof(sliceIndex),
                $"Slice index ({sliceIndex}) is greater than or equal to the texture array size ({texture->ArraySize})");

        if (_activeSlices.TryGetValue(((nint)texture, sliceIndex), out var state))
        {
            state.Refresh();
            return new ImTextureId((nint)state.ShaderResourceView);
        }

        using var srv = new ComPtr<ID3D11ShaderResourceView>((ID3D11ShaderResourceView*)(nint)texture->D3D11ShaderResourceView);
        D3D11_SHADER_RESOURCE_VIEW_DESC description;
        srv.Get()->GetDesc(&description);
        switch (description.ViewDimension)
        {
            case D3D_SRV_DIMENSION.D3D11_SRV_DIMENSION_TEXTURE1D:
            case D3D_SRV_DIMENSION.D3D11_SRV_DIMENSION_TEXTURE2D:
            case D3D_SRV_DIMENSION.D3D11_SRV_DIMENSION_TEXTURE2DMS:
            case D3D_SRV_DIMENSION.D3D11_SRV_DIMENSION_TEXTURE3D:
            case D3D_SRV_DIMENSION.D3D11_SRV_DIMENSION_TEXTURECUBE:
                // This function treats these as single-slice arrays.
                // As per the range check above, the only valid slice (i. e. 0) has been requested, therefore there is nothing to do.
                break;
            case D3D_SRV_DIMENSION.D3D11_SRV_DIMENSION_TEXTURE1DARRAY:
                description.Texture1DArray.FirstArraySlice = sliceIndex;
                description.Texture1DArray.ArraySize       = 1;
                break;
            case D3D_SRV_DIMENSION.D3D11_SRV_DIMENSION_TEXTURE2DARRAY:
                description.Texture2DArray.FirstArraySlice = sliceIndex;
                description.Texture2DArray.ArraySize       = 1;
                break;
            case D3D_SRV_DIMENSION.D3D11_SRV_DIMENSION_TEXTURE2DMSARRAY:
                description.Texture2DMSArray.FirstArraySlice = sliceIndex;
                description.Texture2DMSArray.ArraySize       = 1;
                break;
            case D3D_SRV_DIMENSION.D3D11_SRV_DIMENSION_TEXTURECUBEARRAY:
                description.TextureCubeArray.First2DArrayFace = sliceIndex * 6u;
                description.TextureCubeArray.NumCubes         = 1;
                break;
            default: throw new NotSupportedException($"{nameof(TextureArraySlicer)} does not support dimension {description.ViewDimension}");
        }

        using var device = new ComPtr<ID3D11Device>();
        srv.Get()->GetDevice(device.GetAddressOf());
        using var resource = new ComPtr<ID3D11Resource>();
        srv.Get()->GetResource(resource.GetAddressOf());
        ID3D11ShaderResourceView* slicedSrv = null;
        Marshal.ThrowExceptionForHR(device.Get()->CreateShaderResourceView(resource, &description, &slicedSrv));
        state = new SliceState(slicedSrv);
        _activeSlices.Add(((nint)texture, sliceIndex), state);
        return new ImTextureId((nint)state.ShaderResourceView);
    }

    private void Tick()
    {
        try
        {
            foreach (var (key, slice) in _activeSlices)
            {
                if (!slice.Tick())
                    _expiredKeys.Add(key);
            }

            foreach (var key in _expiredKeys)
                _activeSlices.Remove(key);
        }
        finally
        {
            _expiredKeys.Clear();
        }
    }

    /// <inheritdoc/>
    public void Dispose()
    {
        foreach (var slice in _activeSlices.Values)
            slice.Dispose();
        _activeSlices.Clear();
        ImSharpPerFrame.Update -= Tick;
    }

    private sealed class SliceState(ID3D11ShaderResourceView* shaderResourceView) : IDisposable
    {
        /// <summary> The shader resource view wrapped by this object. </summary>
        public readonly ID3D11ShaderResourceView* ShaderResourceView = shaderResourceView;

        private uint _timeToLive = InitialTimeToLive;

        /// <summary> Lengthens this object's time to live as if it was just created. </summary>
        public void Refresh()
            => _timeToLive = InitialTimeToLive;

        /// <summary> Decreases the time to live of this object, and frees its resources if it has just expired. </summary>
        /// <returns> Whether this object is still fresh. </returns>
        public bool Tick()
        {
            if (unchecked(_timeToLive--) > 0)
                return true;

            if (ShaderResourceView is not null)
                ShaderResourceView->Release();
            return false;
        }

        /// <inheritdoc/>
        public void Dispose()
        {
            if (ShaderResourceView is not null)
                ShaderResourceView->Release();
        }
    }
}
