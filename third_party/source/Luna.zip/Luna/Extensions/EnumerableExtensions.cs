using Luna.Generators;

namespace Luna;

[GenerateArities(9, IncludeZeroArity = true)]
public delegate bool TryFunc<in T1, TRet>(T1 a1, out TRet? ret);

public static partial class EnumerableExtensions
{
    /// <summary> Remove an added index from an indexed enumerable. </summary>
    [MethodImpl(MethodImplOptions.AggressiveInlining | MethodImplOptions.AggressiveOptimization)]
    public static IEnumerable<T> WithoutIndex<T>(this IEnumerable<(int Index, T Value)> list)
        => list.Select(x => x.Value);

    /// <summary> Remove the value and only keep the index from an indexed enumerable. </summary>
    [MethodImpl(MethodImplOptions.AggressiveInlining | MethodImplOptions.AggressiveOptimization)]
    public static IEnumerable<int> WithoutValue<T>(this IEnumerable<(int Index, T Value)> list)
        => list.Select(x => x.Index);

    /// <summary> Find the index of the first object fulfilling <paramref name="predicate"/>'s criteria in <paramref name="array"/>. </summary>
    /// <returns> -1 if no object is found, otherwise the index. </returns>
    public static int IndexOf<T>(this IEnumerable<T> array, Predicate<T> predicate, int from = 0)
    {
        var i = from;
        foreach (var obj in array.Skip(from))
        {
            if (predicate(obj))
                return i;

            ++i;
        }

        return -1;
    }

    /// <summary> Find the index of the first occurrence of <paramref name="needle"/> in <paramref name="array"/>. </summary>
    /// <returns> -1 if <paramref name="needle"/> is not contained, otherwise its index. </returns>
    public static int IndexOf<T>(this IEnumerable<T> array, T needle, int from = 0) where T : notnull
    {
        var i = from;
        foreach (var obj in array.Skip(from))
        {
            if (needle.Equals(obj))
                return i;

            ++i;
        }

        return -1;
    }

    /// <summary> Find the first object fulfilling <paramref name="predicate"/>'s criteria in <paramref name="array"/>>, if one exists. </summary>
    /// <returns> True if an object is found, false otherwise. </returns>
    public static bool FindFirst<T>(this IEnumerable<T> array, Predicate<T> predicate, [NotNullWhen(true)] out T? result)
    {
        foreach (var obj in array)
        {
            if (!predicate(obj))
                continue;

            result = obj!;
            return true;
        }

        result = default;
        return false;
    }

    /// <summary> Find the first occurrence of <paramref name="needle"/> in <paramref name="array"/> and return the value contained in the list in result. </summary>
    /// <returns> True if <paramref name="needle"/> is found, false otherwise. </returns>
    public static bool FindFirst<T>(this IEnumerable<T> array, T needle, [NotNullWhen(true)] out T? result) where T : notnull
    {
        foreach (var obj in array)
        {
            if (!obj.Equals(needle))
                continue;

            result = obj;
            return true;
        }

        result = default;
        return false;
    }

    /// <summary> Transform an enumerable while filtering it at the same time. </summary>
    /// <typeparam name="TIn"> The type of the input objects. </typeparam>
    /// <typeparam name="TOut"> The type of the transformed objects. </typeparam>
    /// <param name="enumerable"> The input objects. </param>
    /// <param name="filterMap"> A function that transforms the input objects into the output objects and also returns a bool whether the output is valid. </param>
    /// <returns> An enumeration of the filtered output objects. </returns>
    [OverloadResolutionPriority(50)]
    public static IEnumerable<TOut> SelectWhere<TIn, TOut>(this IEnumerable<TIn> enumerable, Func<TIn, (bool, TOut?)> filterMap)
    {
        foreach (var obj in enumerable)
        {
            var (valid, transform) = filterMap(obj);
            if (valid)
                yield return transform!;
        }
    }

    /// <summary> Transform an enumerable while filtering it at the same time. </summary>
    /// <typeparam name="TIn"> The type of the input objects. </typeparam>
    /// <typeparam name="TOut"> The type of the transformed objects. </typeparam>
    /// <param name="enumerable"> The input objects. </param>
    /// <param name="filterMap"> A function that transforms the input objects into the output objects and returns a bool whether the output is valid. </param>
    /// <returns> An enumeration of the filtered output objects. </returns>
    [OverloadResolutionPriority(100)]
    public static IEnumerable<TOut?> SelectWhere<TIn, TOut>(this IEnumerable<TIn> enumerable, TryFunc<TIn, TOut> filterMap)
    {
        foreach (var obj in enumerable)
        {
            if (filterMap(obj, out var ret))
                yield return ret;
        }
    }

    /// <summary> Compute the maximum value in a set, or return a default value if the set is empty. </summary>
    /// <typeparam name="TObject"> The type of the objects. </typeparam>
    /// <typeparam name="TValue"> The type of the value to compare. </typeparam>
    /// <param name="enumerable"> The set of objects. </param>
    /// <param name="selector"> The selector to reduce the objects to a specific value. </param>
    /// <param name="ifEmpty"> The default value to return if the set of objects is empty. </param>
    /// <returns> The maximum selected value in the set or <paramref name="ifEmpty"/> if there are no elements in the set. </returns>
    public static TValue Max<TObject, TValue>(this IEnumerable<TObject> enumerable, Func<TObject, TValue> selector, TValue ifEmpty)
        where TValue : IComparable<TValue>
    {
        using var enumerator = enumerable.GetEnumerator();
        if (!enumerator.MoveNext())
            return ifEmpty;

        var comparer = Comparer<TValue>.Default;
        var max      = selector(enumerator.Current);
        while (enumerator.MoveNext())
        {
            var value = selector(enumerator.Current);
            if (comparer.Compare(max, value) < 0)
                max = value;
        }

        return max;
    }

    /// <summary> Compute the minimum value in a set, or return a default value if the set is empty. </summary>
    /// <typeparam name="TObject"> The type of the objects. </typeparam>
    /// <typeparam name="TValue"> The type of the value to compare. </typeparam>
    /// <param name="enumerable"> The set of objects. </param>
    /// <param name="selector"> The selector to reduce the objects to a specific value. </param>
    /// <param name="ifEmpty"> The default value to return if the set of objects is empty. </param>
    /// <returns> The minimum selected value in the set or <paramref name="ifEmpty"/> if there are no elements in the set. </returns>
    public static TValue Min<TObject, TValue>(this IEnumerable<TObject> enumerable, Func<TObject, TValue> selector, TValue ifEmpty)
        where TValue : IComparable<TValue>
    {
        using var enumerator = enumerable.GetEnumerator();
        if (!enumerator.MoveNext())
            return ifEmpty;

        var comparer = Comparer<TValue>.Default;
        var min      = selector(enumerator.Current);
        while (enumerator.MoveNext())
        {
            var value = selector(enumerator.Current);
            if (comparer.Compare(min, value) > 0)
                min = value;
        }

        return min;
    }
}
